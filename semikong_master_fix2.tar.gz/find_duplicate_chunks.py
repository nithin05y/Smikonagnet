"""
find_duplicate_chunks.py -- run this on the pod to diagnose the
"same sentence shown twice under different citation numbers" symptom.

Usage:
    cd /workspace/shared/semikong_complete
    FAKE_EMBEDDINGS=1 CHROMA_DIR=./chroma_db BM25_PATH=./bm25.pkl \
        python3 find_duplicate_chunks.py
"""
import sys
from collections import defaultdict

sys.path.insert(0, ".")
import agent.retrieval as R

R._load()
all_chunks = R._bm25["chunks"]

by_text = defaultdict(list)
for c in all_chunks:
    key = c["text"].strip()
    by_text[key].append(c)

dupes = {k: v for k, v in by_text.items() if len(v) > 1}

print(f"Total chunks: {len(all_chunks)}")
print(f"Distinct text groups with duplicates: {len(dupes)}")
print()

if not dupes:
    print("No exact-duplicate chunk text found. If the symptom is still "
          "happening, the duplicates are near-identical rather than "
          "byte-identical (e.g. differ only by whitespace/page-number "
          "noise) -- let me know and I'll write a near-duplicate check.")
else:
    shown = 0
    for text, group in dupes.items():
        if shown >= 15:
            print(f"... and {len(dupes) - shown} more duplicate groups "
                  f"(truncated for readability)")
            break
        shown += 1
        print(f"--- Duplicated {len(group)}x ---")
        print(f"Text: {text[:100]!r}")
        for c in group:
            print(f"   id={c['id']!s:30s} source_file={c['source_file']}")
        print()

    sources = defaultdict(int)
    for group in dupes.values():
        files = {c["source_file"] for c in group}
        if len(files) > 1:
            sources["SAME TEXT, DIFFERENT FILES (file likely ingested twice)"] += 1
        else:
            sources["SAME TEXT, SAME FILE (chunk-overlap or re-ingest artifact)"] += 1
    print("Summary:")
    for k, v in sources.items():
        print(f"  {v} group(s): {k}")
