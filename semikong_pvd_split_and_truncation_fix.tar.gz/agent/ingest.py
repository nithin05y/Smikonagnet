"""
ingest.py — Document ingestion pipeline: extract → clean → chunk → index.

Builds both indices retrieval.py expects:
  - ChromaDB collection "semikong_fab_kb" at CHROMA_DIR (dense vectors)
  - BM25 pickle at BM25_PATH: {"bm25": BM25Okapi, "chunks": [...]} (sparse)

Each chunk dict: {"id", "text", "source_file", "doc_type"}
ChromaDB metadata mirrors "id" so retrieval.py's
    doc.metadata.get("id") or doc.metadata.get("chunk_id")
fallback resolves correctly.

Supports FAKE_EMBEDDINGS=1 (see fake_embeddings.py) for offline/CI runs.
"""
import os
import re
import pickle
import logging
import argparse
from pathlib import Path
from typing import List, Dict, Optional

log = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
CHUNK_SIZE      = 512
CHUNK_OVERLAP   = 64
MIN_CHUNK_CHARS = 60
COLLECTION_NAME = "semikong_fab_kb"
EMBED_MODEL     = os.getenv("EMBED_MODEL", "BAAI/bge-small-en-v1.5")

DOC_TYPE_MAP = {
    "cmp": "CMP", "secs_gem": "SECS_GEM", "cleanroom": "CLEANROOM",
    "etch": "ETCH", "litho": "LITHO", "lithography": "LITHO",
    "deposition": "DEPOSITION", "furnace": "FURNACE",
    "metrology": "METROLOGY", "process_overview": "PROCESS_OVERVIEW",
    "basics": "BASICS", "pvd": "PVD",
}

EXTENSIONS = (".pdf", ".html", ".htm", ".txt", ".md", ".docx")


# ── Text extraction ───────────────────────────────────────────────────────────

def extract_text(path: Path) -> str:
    ext = path.suffix.lower()
    if ext == ".pdf":
        try:
            import fitz  # PyMuPDF
            doc  = fitz.open(str(path))
            text = "\n\n".join(p.get_text() for p in doc)
            doc.close()
            return text
        except ImportError:
            log.warning("PyMuPDF not installed — skipping PDF %s", path.name)
            return ""
    if ext in (".html", ".htm"):
        from bs4 import BeautifulSoup
        with open(path, encoding="utf-8", errors="ignore") as f:
            soup = BeautifulSoup(f.read(), "html.parser")
        for tag in soup(["script", "style", "nav", "header", "footer"]):
            tag.decompose()
        return soup.get_text(separator="\n", strip=True)
    if ext == ".docx":
        try:
            import docx  # python-docx
            d = docx.Document(str(path))
            parts = [p.text for p in d.paragraphs if p.text.strip()]
            for table in d.tables:
                for row in table.rows:
                    cells = [c.text.strip() for c in row.cells]
                    if any(cells):
                        parts.append(" | ".join(cells))
            return "\n\n".join(parts)
        except ImportError:
            log.warning("python-docx not installed — skipping Word doc %s", path.name)
            return ""
        except Exception as e:
            log.warning("  ERROR reading %s: %s", path.name, e)
            return ""
    return path.read_text(encoding="utf-8", errors="ignore")


def clean_text(raw: str) -> str:
    text = re.sub(r"[ \t]{2,}", " ", raw)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


_HEADING_ONLY_RE = re.compile(r"\d+\.\s+\S.*\S")


def _merge_isolated_headings(raw_chunks: List[str]) -> List[str]:
    """
    RecursiveCharacterTextSplitter occasionally lands a chunk boundary
    right after a numbered section heading (e.g. "9. PVD (PHYSICAL VAPOR
    DEPOSITION) - EQUIPMENT AND OPERATION"), leaving that heading alone
    in its own chunk with zero body text -- a content-free unit that can
    still score on BM25 (the topic words are right there in the title)
    and get retrieved ahead of the chunk that actually answers the
    question. Detect a chunk that is ENTIRELY just one such heading line
    (no embedded newline) and prepend it onto the next chunk instead of
    keeping it standalone.
    """
    merged: List[str] = []
    pending: Optional[str] = None
    for t in raw_chunks:
        s = t.strip()
        if pending:
            s = pending + "\n" + s
            pending = None
        if "\n" not in s and _HEADING_ONLY_RE.fullmatch(s):
            pending = s
            continue
        merged.append(s)
    if pending:  # heading-only chunk at the very end of the file
        merged.append(pending)
    return merged


def chunk_text(text: str, source_file: str, doc_type: str) -> List[Dict]:
    """Split text into overlapping chunks with stable IDs."""
    try:
        from langchain_text_splitters import RecursiveCharacterTextSplitter
    except ImportError:
        from langchain.text_splitter import RecursiveCharacterTextSplitter

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    raw_chunks = _merge_isolated_headings(splitter.split_text(text))
    base = re.sub(r"[^a-z0-9]", "_", Path(source_file).stem.lower())[:24]

    chunks = []
    for i, t in enumerate(raw_chunks):
        t = t.strip()
        if len(t) < MIN_CHUNK_CHARS:
            continue
        chunks.append({
            "id": f"{base}_c{i:04d}",
            "text": t,
            "source_file": source_file,
            "doc_type": doc_type,
        })
    return chunks


def infer_doc_type(path: Path, corpus_dir: Path) -> str:
    try:
        rel = path.relative_to(corpus_dir)
        top = rel.parts[0] if len(rel.parts) > 1 else "misc"
    except ValueError:
        top = "misc"
    return DOC_TYPE_MAP.get(top, "MISC")


# ── Embeddings ────────────────────────────────────────────────────────────────

def _get_embeddings():
    """FAKE_EMBEDDINGS=1 → deterministic local embedder (no network).
    Otherwise → BAAI/bge-small-en-v1.5 via HuggingFace."""
    if os.getenv("FAKE_EMBEDDINGS") == "1":
        try:
            from .fake_embeddings import FakeEmbeddings
        except ImportError:
            from fake_embeddings import FakeEmbeddings
        log.info("Using FakeEmbeddings (offline mode)")
        return FakeEmbeddings()

    from langchain_community.embeddings import HuggingFaceBgeEmbeddings
    log.info("Loading embedding model: %s", EMBED_MODEL)
    return HuggingFaceBgeEmbeddings(
        model_name=EMBED_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )


# ── Public API ────────────────────────────────────────────────────────────────

def ingest_corpus(corpus_dir: str, chroma_dir: str, bm25_path: str) -> int:
    """
    Walk corpus_dir, extract/chunk all supported files, write:
      - ChromaDB collection at chroma_dir
      - BM25 pickle at bm25_path

    Returns total chunk count.
    """
    from langchain_community.vectorstores import Chroma
    from rank_bm25 import BM25Okapi

    cdir = Path(corpus_dir).expanduser()
    if not cdir.exists():
        raise FileNotFoundError(f"Corpus directory not found: {cdir}")

    emb = _get_embeddings()
    db  = Chroma(
        collection_name=COLLECTION_NAME,
        persist_directory=os.path.expanduser(chroma_dir),
        embedding_function=emb,
    )

    files = sorted(p for p in cdir.rglob("*")
                   if p.suffix.lower() in EXTENSIONS and p.is_file())
    log.info("Ingesting %d files from %s", len(files), cdir)

    all_chunks: List[Dict] = []
    for fp in files:
        try:
            text = clean_text(extract_text(fp))
        except Exception as e:
            log.error("  ERROR reading %s: %s", fp.name, e)
            continue

        if len(text) < MIN_CHUNK_CHARS:
            log.warning("  SKIP %s: too short after extraction", fp.name)
            continue

        dt     = infer_doc_type(fp, cdir)
        chunks = chunk_text(text, fp.name, dt)
        if not chunks:
            continue

        db.add_texts(
            texts=[c["text"] for c in chunks],
            ids=[c["id"] for c in chunks],
            metadatas=[{"id": c["id"],
                        "source_file": c["source_file"],
                        "doc_type": c["doc_type"]} for c in chunks],
        )
        all_chunks.extend(chunks)
        log.info("  %-40s %3d chunks  [%s]", fp.name, len(chunks), dt)

    if hasattr(db, "persist"):
        try:
            db.persist()
        except Exception:
            pass  # newer Chroma versions persist automatically

    # BM25 — build even on empty corpus to avoid downstream FileNotFoundError
    tokenized = [c["text"].lower().split() for c in all_chunks] or [["placeholder"]]
    bm25 = BM25Okapi(tokenized)

    bm25_path_full = os.path.expanduser(bm25_path)
    os.makedirs(os.path.dirname(bm25_path_full) or ".", exist_ok=True)
    with open(bm25_path_full, "wb") as f:
        pickle.dump({"bm25": bm25, "chunks": all_chunks}, f, protocol=4)

    log.info("Ingest complete: %d total chunks -> %s", len(all_chunks), bm25_path_full)
    return len(all_chunks)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    p = argparse.ArgumentParser(description="Ingest corpus into ChromaDB + BM25")
    p.add_argument("--corpus-dir", default="./corpus")
    p.add_argument("--chroma-dir", default=os.getenv("CHROMA_DIR", "~/shared/chroma_db"))
    p.add_argument("--bm25-path",  default=os.getenv("BM25_PATH",  "~/shared/bm25.pkl"))
    args = p.parse_args()

    n = ingest_corpus(args.corpus_dir, args.chroma_dir, args.bm25_path)
    print(f"\nIngested {n} chunks.")
    print(f"  ChromaDB: {os.path.expanduser(args.chroma_dir)}")
    print(f"  BM25:     {os.path.expanduser(args.bm25_path)}")
