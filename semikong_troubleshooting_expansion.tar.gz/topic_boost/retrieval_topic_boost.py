"""
retrieval_topic_boost.py — Independent, additive layer on top of
agent.retrieval.retrieve().

WHY THIS EXISTS
---------------
On a corpus dominated by one or two huge generic documents (e.g. a
2000-chunk semiconductor textbook), small topic-specific files --
secs_gem_overview.txt, cleanroom_sop.txt, cmp_primer.txt -- can get
crowded out of the hybrid RRF results even when the operator's query is
clearly about that topic. (Symptom seen on the 7663-chunk corpus: asking
about "SECS/GEM Stream and Function" returned zero chunks from
secs_gem_overview.txt.)

WHAT THIS DOES
--------------
Detects topic keywords in the query (SECS/GEM, CMP, cleanroom, etc. --
the SAME doc_type tags agent/ingest.py already assigns to chunks). If a
match is found AND chunks with that tag exist, the top-scoring chunk(s)
carrying that tag are guaranteed to appear first in the result, with the
remaining slots filled from the normal hybrid retrieve() result.

WHAT THIS DOES NOT DO
---------------------
- Does NOT modify agent/retrieval.py, agent/ingest.py, agent/chat_agent.py,
  mock_vllm/server.py, or ui/gradio_app.py. Purely additive: imports and
  calls the existing retrieve(), nothing more. Safe to add without
  touching anything that currently works.
- Does NOT override abstention. If the underlying retrieve() abstains
  ("no_relevant_context") or errors, this returns that result completely
  unchanged -- this layer only re-ranks WITHIN an already-successful
  retrieval, it doesn't try to rescue a query retrieve() rejected.
- Does NOT fix general "irrelevant chunk on a nonsense query" issues
  (that's a FakeEmbeddings-at-scale issue, addressed separately by
  switching to real BGE embeddings). This addresses a different,
  narrower problem: "relevant small file buried by a huge unrelated one."

If no topic keyword matches, or the matched tag has zero chunks in this
corpus, this returns EXACTLY what retrieve() would have returned -- zero
behavior change in those cases.
"""
import os
import sys
from typing import Dict, List, Optional, Tuple

# Make `agent` importable when this file lives in <project_root>/topic_boost/
_HERE = os.path.dirname(os.path.abspath(__file__))
_PARENT = os.path.dirname(_HERE)


def _find_project_root() -> str:
    """Locate the main SemiKong project folder (the one containing
    agent/), so this module works whether topic_boost/ lives INSIDE
    that project or as a SIBLING folder next to it.

    Checks, in order:
      1. SEMIKONG_PROJECT_ROOT env var (explicit override)
      2. A sibling folder named "Smikonagnet"
      3. This folder's own parent (topic_boost/ inside the project --
         original layout)
    """
    for c in (os.environ.get("SEMIKONG_PROJECT_ROOT"),
              os.path.join(_PARENT, "Smikonagnet"),
              _PARENT):
        if c and os.path.isdir(os.path.join(c, "agent")):
            return os.path.abspath(c)
    raise RuntimeError(
        "topic_boost: could not find the SemiKong project folder (looked "
        "for a subfolder named 'agent'). If this is in a different "
        "location, set SEMIKONG_PROJECT_ROOT, e.g.:\n"
        "    export SEMIKONG_PROJECT_ROOT=/workspace/shared/Smikonagnet"
    )


_PROJECT_ROOT = _find_project_root()
for _p in (_PROJECT_ROOT, _PARENT):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from agent import retrieval as R  # noqa: E402


# Keyword -> doc_type tag, mirroring agent/ingest.py's DOC_TYPE_MAP values.
# Dict order = priority order: the FIRST matching tag wins per query.
_TOPIC_KEYWORDS: Dict[str, List[str]] = {
    "SECS_GEM": [
        "secs/gem", "secs-gem", "secs gem", "gem standard",
        "stream and function", "hsms", "semi e30", "semi e37",
        "semi e5", "semi e4", "host communication", "equipment communication",
    ],
    "CMP": [
        "cmp", "chemical mechanical", "chemical-mechanical", "slurry",
        "dishing", "planariz", "pad condition", "removal rate",
        "carrier head", "polishing pad",
    ],
    "CLEANROOM": [
        "cleanroom", "clean room", "gowning", "bunny suit",
        "particle count", "contamination control", "gown up",
    ],
    "ETCH": ["etch", "etching", "reactive ion etch", " rie ", "plasma etch"],
    "LITHO": [
        "litho", "lithography", "photoresist", "stepper",
        "exposure dose", "mask aligner",
    ],
    "DEPOSITION": ["deposition", " cvd", "ald "],
    "PVD": [" pvd", "physical vapor deposition", "sputter",
            "sputtering", "evaporator", "evaporation"],
    "FURNACE": ["furnace", "anneal", "oxidation", "thermal diffusion"],
    "METROLOGY": [
        "metrology", "overlay measurement", "cd measurement",
        "film thickness measurement",
    ],
    "PROCESS_OVERVIEW": [
        "process overview", "fab overview", "process flow",
        "step by step", "step-by-step", "front end", "front-end",
        "feol", "process steps", "fabrication process",
        "process sequence", "manufacturing steps", "fab process",
        "unit process", "unit processes", "basic unit",
    ],
    "EQUIPMENT_DOWN": [
        "equipment down", "first response checklist",
        "tool not working checklist", "down troubleshooting checklist",
    ],
    "GENERAL_TROUBLESHOOTING": [
        "vacuum failure", "vacuum leak", "chamber leak",
        "recipe fail", "recipe failed", "recipe won't start",
        "recipe wont start", "process won't start", "process wont start",
        "recipe stopped", "recipe won't run", "recipe wont run",
        "frequent alarm", "alarms keep", "repeated alarm", "alarm history",
        "particle contamination", "particles on wafer",
        "chamber contamination", "flaking",
        "machine stops", "tool stops", "stops during operation",
        "stops mid", "stopped mid",
        "low yield", "defective wafer", "yield is low",
        "wafers are defective", "yield drop",
    ],
    "BASICS": [
        "what is a wafer", "what is wafer", "what's a wafer",
        "define wafer", "wafer mean",
        "what is a die", "what is die", "what's a die", "define die",
        "semiconductor die", "die mean",
        "equipment heating", "equipment is heating", "tool is heating",
        "tool heating", "overheating", "over heating", "too hot",
        "equpment heating", "equpment is heating", "equipement heating",
        "equipement is heating",
        "temperature alarm", "temperature is high", "temperature too high",
        "gas flow is low", "gas flow low", "low gas flow",
        "gas is low", "gas is less", "less gas", "gas low",
        "n2 purge", "nitrogen purge", "vacuum loss", "pressure alarm",
        "interlock tripped", "utility alarm",
    ],
}


_ABSTAIN_RESCUE_MIN_SCORE = 1.0


def _abstain_rescue(
    query: str, tag: str, k: int
) -> Tuple[List[dict], str, Optional[str]]:
    """
    Called only when retrieve() abstained but the query matched a
    curated tag. Ranks that tag's own chunks by BM25 alone (bypassing
    the dense gate that caused the abstention). Only returns "ok" if the
    top score clears _ABSTAIN_RESCUE_MIN_SCORE -- a tag keyword appearing
    in the query is not, by itself, enough; the matched content also has
    to score as a genuine match, not an incidental overlap.
    """
    try:
        R._load()
        all_chunks = R._bm25["chunks"]
        bm25 = R._bm25["bm25"]
    except Exception:
        return [], "no_relevant_context", None

    tag_indices = [i for i, c in enumerate(all_chunks) if c.get("doc_type") == tag]
    if not tag_indices:
        return [], "no_relevant_context", None

    tok_q = query.lower().split()
    scores = bm25.get_scores(tok_q)
    ranked = sorted(tag_indices, key=lambda i: -scores[i])

    if scores[ranked[0]] < _ABSTAIN_RESCUE_MIN_SCORE:
        return [], "no_relevant_context", None

    rescued = [all_chunks[i] for i in ranked[:k]]
    return rescued, "ok", tag


def match_tag(query: str) -> Optional[str]:
    """Return the first doc_type tag whose keyword(s) appear in `query`,
    or None if nothing matches."""
    q = " " + query.lower() + " "
    for tag, keywords in _TOPIC_KEYWORDS.items():
        for kw in keywords:
            if kw in q:
                return tag
    return None


def retrieve_with_topic_boost(
    query: str, k: int = 5, boost_slots: Optional[int] = None
) -> Tuple[List[dict], str, Optional[str]]:
    """
    Drop-in alternative to agent.retrieval.retrieve(query, k) that adds a
    topic-tag boost. Returns (chunks, status, matched_tag).

      - boost_slots: how many of the result's k slots are guaranteed to
        come from the matched tag's own chunks (ranked by BM25 within
        the tag), before falling back to baseline to fill any remaining
        slots. Defaults to k -- i.e. fill the ENTIRE result from the
        matched tag if it has enough chunks. This matters: once a topic
        has a real curated primer (CMP, DEPOSITION, BASICS,
        PROCESS_OVERVIEW all have 8-14 chunks now), capping at a small
        fixed number of guaranteed slots meant 2 clean chunks would
        still get diluted by 3 baseline slots pulled from noisy OCR
        textbook fragments. Pass an explicit smaller boost_slots (as the
        tests do) to keep the old "guarantee only N, blend with
        baseline" behavior for a specific call.
      - status is identical to what retrieve() would return
        ("ok" | "no_relevant_context" | "error") -- UNLESS the dense
        abstain-rescue below fires, in which case status is upgraded to
        "ok". See _ABSTAIN_RESCUE_MIN_SCORE.
      - matched_tag is the doc_type tag detected in the query (e.g.
        "SECS_GEM"), or None if no tag matched, the tag has zero chunks
        in this corpus, or status != "ok" and no rescue applied.
      - If matched_tag is None, `chunks` is EXACTLY retrieve()'s result --
        no copying/reordering, true passthrough.

    DENSE ABSTAIN-RESCUE (narrow, deliberate exception):
    retrieve()'s abstain decision is gated purely on dense/embedding
    distance. With FakeEmbeddings (hash-based, not semantically
    meaningful), a short or novel-phrased query can hash far from every
    chunk vector even when a real keyword match exists -- e.g. "is gas
    is less" abstained even though glossary_and_alarms.txt's gas-flow
    section scored 4.7 on BM25 alone. If retrieve() abstains BUT the
    query matches one of the curated _TOPIC_KEYWORDS phrases above AND
    that tag's best BM25 score clears _ABSTAIN_RESCUE_MIN_SCORE, this
    layer rescues the query using BM25-only ranking within that tag.
    This does NOT relax abstention generally -- a genuinely off-topic or
    nonsense query won't match any curated phrase, so it still abstains
    exactly as before.
    """
    if boost_slots is None:
        boost_slots = k

    baseline, status = R.retrieve(query, k=k)
    tag = match_tag(query)

    if status != "ok":
        if tag is None:
            return baseline, status, None
        return _abstain_rescue(query, tag, k)

    if tag is None:
        return baseline, status, None

    R._load()  # idempotent singleton init; cheap if already loaded
    all_chunks = R._bm25["chunks"]
    bm25 = R._bm25["bm25"]

    tag_indices = [i for i, c in enumerate(all_chunks) if c.get("doc_type") == tag]
    if not tag_indices:
        # Tag matched linguistically, but no chunks carry it. No-op.
        return baseline, status, None

    tok_q = query.lower().split()
    scores = bm25.get_scores(tok_q)
    tag_ranked = sorted(tag_indices, key=lambda i: -scores[i])[:boost_slots]
    boosted = [all_chunks[i] for i in tag_ranked]

    seen = set()
    merged: List[dict] = []
    for c in boosted + baseline:
        cid = c["id"]
        if cid not in seen:
            seen.add(cid)
            merged.append(c)
        if len(merged) >= k:
            break

    return merged, status, tag
