# SemiKong Fab Troubleshooting Agent

Conversational shopfloor troubleshooting **chatbot** for semiconductor fab
operators. v3 adds a multi-turn conversational core on top of the v2 RAG
pipeline (ChromaDB + BM25 + RRF retrieval, SemiKong-8B generator, and a
per-claim critic that strips unsupported claims before the answer reaches
the operator):

- **Planner** classifies each message's intent (smalltalk / clarify /
  retrieve / escalate) and, for follow-ups, rewrites a short message like
  "radial" into a standalone search query using prior turns — e.g.
  `"EQ-CMP-03 radial wafer troubleshooting"`. This query-rewrite is what
  makes it a *chatbot* rather than a search box: the agent remembers what
  tool and symptom you were discussing.
- **Conversation** holds a sliding window of turns plus an `escalated` flag.
- The v2 retrieve -> generate -> critique pipeline runs only on
  retrieve-intent turns, exactly as before.

This package runs **end-to-end on Ubuntu with no GPU**, using:
- `FakeEmbeddings` (deterministic, no HuggingFace download)
- a mock vLLM server (`mock_vllm/`) that mimics SemiKong-8B's structured
  JSON output for all three roles — planner, conversational generator, and
  critic — plus the v2 single-shot generator for backward compatibility.

Swap in real BGE embeddings and a real vLLM+SemiKong-8B endpoint on the
AMD MI300X pod by unsetting `FAKE_EMBEDDINGS` and pointing `VLLM_URL` /
`MODEL_PATH` at the real server — no code changes needed (planner, generator,
and critic all share the same `_get_llm()` factory).

---

## Quick start (one command)

```bash
chmod +x run_demo.sh
./run_demo.sh
```

This installs dependencies, ingests the sample corpus, starts the mock
vLLM server, runs the v2 5-query demo, runs the v3 conversational demo
(including THE KEY TEST — the "radial" follow-up rewrite), and runs the
full 100+ test pytest suite. Total runtime: under a minute.

Then start the chat UI:
```bash
python -m ui.gradio_app
```
Open the printed `.gradio.live` link — chat on the left, a live trace
panel (intent, rewritten query, retrieved chunks, critic verdict) on the
right.

---

## Project layout

```
semikong_agent/
├── agent/
│   ├── __init__.py
│   ├── schema.py           Pydantic models (Claim, AgentAnswer, VerifiedAnswer)
│   ├── ingest.py            corpus -> ChromaDB + BM25
│   ├── retrieval.py         hybrid dense+sparse retrieval, RRF merge
│   ├── generator.py          v2 single-shot LLM call -> structured JSON
│   ├── chat_agent.py          v3 conversational core: Conversation, plan(),
│   │                           generate(), handle_turn() — THE CHATBOT
│   ├── critic.py              per-claim SUPPORTED/NOT_SUPPORTED verification
│   ├── orchestrator.py         v2 troubleshoot(): retrieve -> generate -> critique
│   └── fake_embeddings.py       deterministic embedder for offline runs
├── mock_vllm/
│   └── server.py            FastAPI mock of vLLM — routes to planner /
│                              conversational generator / v2 generator /
│                              critic based on system-prompt content
├── ui/
│   ├── __init__.py
│   └── gradio_app.py          chat UI + live trace panel (run_demo.sh prints
│                                the launch command at the end)
├── corpus/                   sample SOPs (CMP, SECS/GEM, cleanroom) — add
│                              your own subfolders here too
├── tests/
│   ├── test_all.py            v2 tests (retrieval, generator, critic, orchestrator)
│   └── test_chat_agent.py      v3 tests (Conversation, plan, generate,
│                                handle_turn — including THE KEY TEST)
├── demo.py                    v2: runs troubleshoot() on 5 representative queries
├── chat_demo.py                v3: runs the "radial" follow-up + DEMO-1 scripts
├── ask.py / search_docs.py /
│   search_ui.py / diagnose.py   standalone helper tools (see their own docstrings)
├── start_server.sh / stop_server.sh   start/stop the mock vLLM in the background
├── run_demo.sh                 one-command install + ingest + demo + test
└── requirements.txt
```

---

## Manual steps (if you don't use run_demo.sh)

### 1. Install dependencies
```bash
# Core (everything needed for offline/mock demo + tests)
pip install -r requirements.txt --break-system-packages

# Optional: real BGE embeddings + Gradio UI (needs more disk/network)
pip install -r requirements-extra.txt --break-system-packages
```

### 2. Ingest the corpus
```bash
export FAKE_EMBEDDINGS=1   # omit on the AMD pod for real BGE embeddings
export CHROMA_DIR=./chroma_db
export BM25_PATH=./bm25.pkl

python -m agent.ingest --corpus-dir ./corpus \
    --chroma-dir "$CHROMA_DIR" --bm25-path "$BM25_PATH"
```

### 3. Start the LLM backend

**Offline / mock (this package):**
```bash
export VLLM_URL=http://localhost:8000/v1
export MODEL_PATH=mock-semikong
python -m mock_vllm.server &
```

**Real SemiKong-8B on the AMD pod (vLLM):**
```bash
export VLLM_URL=http://localhost:8000/v1
export MODEL_PATH=/tmp/models/SEMIKONG-8b-GPTQ
unset FAKE_EMBEDDINGS
# vLLM server already running per Session 1 bootstrap
```

### 4. Run the demo
```bash
python demo.py
```

### 5. Run the tests
```bash
python -m pytest tests/ -v
```

---

## Using the agent in your own code

```python
from agent.orchestrator import troubleshoot

result = troubleshoot("Operator reports dishing on tungsten plugs after CMP.")

if result["abstained"]:
    print("Abstained:", result["abstain_reason"])
    print("Action:", result["suggested_action"])
else:
    for claim in result["claims"]:
        print(f"[{claim['critic_verdict']}] {claim['text']}")
        print("  sources:", claim["source_ids"])
```

`troubleshoot()` never raises — every failure mode (no relevant context,
LLM error, critic error, all claims unsupported) becomes a structured
`abstained=True` response with `abstain_reason` and `suggested_action`
set, plus a `trace` dict with retrieval status, retrieved chunk IDs, and
latency breakdown.

---

## The chat agent (v3) — multi-turn conversation

```python
from agent.chat_agent import Conversation, handle_turn
from agent.retrieval import retrieve
from agent.critic import verify_answer

convo = Conversation()

reply, trace = handle_turn(convo, "EQ-CMP-03, removal rate is uneven",
                            retrieve, verify_answer)
print(reply)
# -> "Uneven CMP removal commonly points to pad-conditioner wear,
#     slurry flow variation, or down-force non-uniformity. [1]
#
#     Follow-up: Is the unevenness center-to-edge or radial?"

reply, trace = handle_turn(convo, "radial", retrieve, verify_answer)
print(trace["plan"]["standalone_query"])
# -> "EQ-CMP-03 radial wafer troubleshooting"
print(reply)
# -> "Radial non-uniformity ... carrier-head pressure imbalance or pad
#     surface degradation ... [1]
#
#     Suggested action: Check the pad-conditioner diamond-disk wear
#     before adjusting carrier pressure ..."
```

**`handle_turn(convo, message, retrieve_fn, verify_fn)`** returns
`(reply_text, trace_dict)` and never raises. Each turn:

1. `plan(convo)` — one LLM call classifies intent and, for `retrieve`,
   rewrites a standalone query using `convo.history_text()`. On bad/empty
   JSON it falls back to `intent="retrieve"` with the raw message — the
   agent always tries to help rather than going silent.
2. Route on intent:
   - `smalltalk` -> canned "what equipment and symptom?" reply
   - `clarify` -> ask `plan()`'s `clarifying_question`
   - `escalate` -> set `convo.escalated = True`, hand-off message
   - `retrieve` -> `retrieve_fn(standalone_query, k=5)` ->
     `generate(convo, chunks)` -> `verify_fn(...)` -> render with `[n]`
     citation markers, `Follow-up:` and `Suggested action:` lines appended
     when present.

**`Conversation`** keeps a sliding window (`max_turns=20`) of `Turn`
objects (`role`, `content`, `metadata`) and an `escalated` flag.
`history_text(n=8)` formats the last *n* turns as `OPERATOR: ...` /
`AGENT: ...` lines — this is what the planner reads to do the rewrite.

### The mock LLM's three roles

`mock_vllm/server.py` serves THREE different response shapes from ONE
endpoint, exactly like the real architecture (one model, three system
prompts):

| Caller | Detected by | Returns |
|---|---|---|
| `chat_agent.plan()` | system prompt contains `"planning module"` | `{intent, standalone_query, clarifying_question, rationale}` |
| `chat_agent.generate()` | system prompt contains `"follow_up_question"` | `{abstained, abstain_reason, claims, follow_up_question, suggested_action}` |
| `generator.generate()` (v2) | neither marker present | `{abstained, abstain_reason, claims, suggested_action}` |
| `critic._critique_claim()` | `guided_choice` in `extra_body` | `"SUPPORTED"` or `"NOT_SUPPORTED"` |

The mock planner's rewrite rule is the mock implementation of **THE
DEFINING FEATURE**: a short follow-up (≤3 words, no tool ID/topic of its
own) is rewritten by combining the tool ID + topic found in earlier turns
with the follow-up word — `"radial"` after an `EQ-CMP-03` CMP turn becomes
`"EQ-CMP-03 radial wafer troubleshooting"`. `chat_demo.py` and
`tests/test_chat_agent.py::TestRadialFollowUpRewrite` both check this.

### Chat UI

```bash
python -m ui.gradio_app
```
Two columns: chat on the left (powered by `handle_turn()`), a live trace
panel on the right showing intent, planner rationale, the rewritten query,
retrieved chunk previews, and how many claims the critic accepted vs
stripped. Runs on port **7861** (separate from `search_ui.py`'s 7860, so
both can run at once) and prints a `.gradio.live` public link.

Try the **DEMO-1** sequence via the example buttons:
1. *"I have a problem with CMP"* -> clarify: "Which tool ID, and what's
   the specific symptom?"
2. *"EQ-CMP-03, removal rate is uneven"* -> pad-conditioner/slurry/
   down-force claims + follow-up "center-to-edge or radial?"
3. *"Radial"* -> trace panel shows the rewritten query, then a
   carrier-head-pressure / diamond-disk-wear diagnosis.

---

## Environment variables

| Variable             | Default                          | Notes                                    |
|----------------------|-----------------------------------|------------------------------------------|
| `CHROMA_DIR`         | `~/shared/chroma_db`              | ChromaDB persistence directory            |
| `BM25_PATH`          | `~/shared/bm25.pkl`               | BM25 index pickle                         |
| `VLLM_URL`           | `http://localhost:8000/v1`        | OpenAI-compatible vLLM endpoint — used by planner, generator, AND critic |
| `MODEL_PATH`         | `/tmp/models/SEMIKONG-8b-GPTQ`    | Model name/path passed to vLLM            |
| `EMBED_MODEL`        | `BAAI/bge-small-en-v1.5`          | HF embedding model (ignored if FAKE)      |
| `DISTANCE_THRESHOLD` | `1.47` (FakeEmbeddings) / `0.5` (real BGE) | CRAG abstain gate — auto-selected by `FAKE_EMBEDDINGS`; override to tune |
| `FAKE_EMBEDDINGS`    | unset                              | `1` -> deterministic local embedder       |

### Connecting the real SemiKong-8B model

Nothing in `chat_agent.py`, `generator.py`, or `critic.py` needs to
change. On the AMD pod, once vLLM is serving SemiKong-8B-GPTQ on `:8000`:

```bash
unset FAKE_EMBEDDINGS
export VLLM_URL=http://localhost:8000/v1
export MODEL_PATH=/tmp/models/SEMIKONG-8b-GPTQ
python -m agent.ingest --corpus-dir ./corpus   # re-ingest with real BGE embeddings
python -m ui.gradio_app
```
The planner, conversational generator, and critic all call `_get_llm()`
(from `generator.py`), which reads `VLLM_URL`/`MODEL_PATH` at call time —
so the real model serves all three roles via its three different system
prompts, same as the mock does.

---

## Adding real documents to the corpus

Drop `.pdf`, `.html`, `.txt`, or `.md` files into subfolders of `corpus/`.
The subfolder name becomes the `doc_type` metadata (e.g. `corpus/cmp/` ->
`doc_type=CMP`). Re-run ingestion to rebuild both indices.
