#!/usr/bin/env bash
# ============================================================
# run_demo.sh
# One-command setup + end-to-end test for the SemiKong agent.
#
# Usage:
#   chmod +x run_demo.sh
#   ./run_demo.sh              # offline mode (FakeEmbeddings, mock vLLM)
#   ./run_demo.sh --real       # real BGE embeddings (needs internet)
#                               # still uses mock vLLM unless VLLM_URL is set
#
# What it does:
#   1. pip install -r requirements.txt
#   2. Ingest ./corpus -> ./chroma_db + ./bm25.pkl
#   3. Launch mock_vllm.server on :8000 (background)
#   4. Run demo.py (v2 single-shot, 5 representative queries)
#   5. Run chat_demo.py (v3 multi-turn -- TS-05 "radial" rewrite, DEMO-1,
#      escalation, off-domain abstention)
#   6. Run the full pytest suite (tests/)
#   7. Tear down the mock server
#
# After this completes, launch the chat UI separately with:
#   python -m ui.gradio_app
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"

MODE="offline"
if [[ "${1:-}" == "--real" ]]; then
    MODE="real"
fi

export CHROMA_DIR="${CHROMA_DIR:-./chroma_db}"
export BM25_PATH="${BM25_PATH:-./bm25.pkl}"
export VLLM_URL="${VLLM_URL:-http://localhost:8000/v1}"
export MODEL_PATH="${MODEL_PATH:-mock-semikong}"
# DISTANCE_THRESHOLD: leave unset so retrieval.py picks the right default
# for the active embedding backend (1.47 for FakeEmbeddings, 0.5 for BGE).
# Override here if you want to tune the CRAG abstain gate explicitly.

if [[ "$MODE" == "offline" ]]; then
    export FAKE_EMBEDDINGS=1
    echo ">> Mode: OFFLINE (FakeEmbeddings — no internet/HF download needed)"
else
    unset FAKE_EMBEDDINGS || true
    echo ">> Mode: REAL embeddings (BAAI/bge-small-en-v1.5 — requires internet)"
fi

echo ""
echo "==> [1/6] Installing dependencies..."
pip install -q -r requirements.txt --break-system-packages 2>&1 | tail -5

echo ""
echo "==> [2/6] Ingesting corpus..."
rm -rf "$CHROMA_DIR" "$BM25_PATH"
python -m agent.ingest --corpus-dir ./corpus --chroma-dir "$CHROMA_DIR" --bm25-path "$BM25_PATH"

echo ""
echo "==> [3/6] Starting mock vLLM server on :8000..."
python -m mock_vllm.server &
MOCK_PID=$!
trap "kill $MOCK_PID 2>/dev/null || true" EXIT

# Wait for health check
for i in $(seq 1 20); do
    if curl -sf http://localhost:8000/health >/dev/null 2>&1; then
        echo "    Mock vLLM is up (pid $MOCK_PID)"
        break
    fi
    sleep 0.3
    if [[ $i -eq 20 ]]; then
        echo "    ERROR: mock vLLM did not start"
        exit 1
    fi
done

echo ""
echo "==> [4/6] Running demo.py (v2 single-shot, 5 queries)..."
python demo.py

echo ""
echo "==> [5/6] Running chat_demo.py (v3 multi-turn -- TS-05 'radial' rewrite)..."
python chat_demo.py

echo ""
echo "==> [6/6] Running pytest suite..."
python -m pytest tests/ -v

echo ""
echo "============================================================"
echo " All steps completed successfully."
echo " - Indices:      $CHROMA_DIR , $BM25_PATH"
echo " - Demo results: ./demo_results.json"
echo ""
echo " Next: launch the chat UI with:"
echo "     python -m ui.gradio_app"
echo "============================================================"
