"""
chat_agent.py — Multi-turn conversational core (v3).

v2 (orchestrator.py) was single-shot: retrieve -> generate -> critique -> return.
v3 adds a PLANNING stage in front of that pipeline:

    handle_turn()
        1. plan()      -> {intent, standalone_query, clarifying_question, rationale}
        2. route on intent:
               smalltalk -> canned reply
               clarify   -> ask clarifying_question
               escalate  -> set convo.escalated, hand off
               retrieve  -> retrieve(standalone_query) -> generate() -> verify_fn()
        3. render reply with [n] citation markers + follow-up/suggested-action

Conversation holds a sliding window of Turns so the planner can rewrite
short follow-ups ("radial") into standalone queries using prior context
("EQ-CMP-03 CMP radial wafer unevenness troubleshooting").

Robustness (same philosophy as generator.py / orchestrator.py):
  - _parse_json (imported from generator.py) -- never raises on bad LLM JSON
  - _get_llm() lazy factory -- env-based MODEL_PATH / VLLM_URL, no module-level client
  - generate() validates source_ids against retrieved chunks (strips hallucinated IDs)
  - handle_turn() wraps plan() / generate() / verify_fn() / retrieve_fn() in
    try/except -- never raises; degrades to a safe reply + trace on any error
"""
import logging
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from .generator import _parse_json, _get_llm

log = logging.getLogger(__name__)


# ── Conversation state ─────────────────────────────────────────────────────

class Turn(BaseModel):
    role: Literal["operator", "agent"]
    content: str
    metadata: Dict[str, Any] = Field(default_factory=dict)


class Conversation:
    """Sliding window of Turns + an escalation flag."""

    def __init__(self, max_turns: int = 20):
        self.turns: List[Turn] = []
        self.max_turns = max_turns
        self.escalated = False

    def add(self, role: str, content: str, metadata: Optional[dict] = None) -> None:
        self.turns.append(Turn(role=role, content=content, metadata=metadata or {}))
        if len(self.turns) > self.max_turns:
            self.turns = self.turns[-self.max_turns:]

    def history_text(self, n: int = 8) -> str:
        if not self.turns:
            return ""
        return "\n".join(f"{t.role.upper()}: {t.content}" for t in self.turns[-n:])


# ── Planner: intent + standalone-query rewrite in ONE call ──────────────────

PLANNER_SYS = """\
You are the planning module of a fab troubleshooting assistant.
Read the conversation so far and the OPERATOR's latest message.
Decide one intent:

- "smalltalk":  greeting, thanks, off-topic. No retrieval needed.
- "clarify":    request too vague; ask one specific question.
- "retrieve":   substantive technical question; need to search docs.
- "escalate":   operator frustrated, in danger, or asks for a human.

If intent is "retrieve": write a STANDALONE search query that folds in
context from earlier turns (tool ID, alarm code, symptom). The query
must work alone, without the conversation history.

If intent is "clarify": write ONE specific question.

Return STRICT JSON, no prose:
{
  "intent": "smalltalk"|"clarify"|"retrieve"|"escalate",
  "standalone_query": string or null,
  "clarifying_question": string or null,
  "rationale": "one line"
}\
"""

_VALID_INTENTS = {"smalltalk", "clarify", "retrieve", "escalate"}


def plan(convo: Conversation) -> dict:
    """Classify intent and (if retrieve) rewrite a standalone query.

    Never raises. On any LLM/parse failure, falls back to
    intent="retrieve" using the operator's raw latest message — i.e.
    the safest default is "try to search", not "say nothing".
    """
    last_msg = convo.turns[-1].content if convo.turns else ""
    fallback = {
        "intent": "retrieve",
        "standalone_query": last_msg,
        "clarifying_question": None,
        "rationale": "fallback",
    }

    user = f"Conversation so far:\n{convo.history_text(n=8)}\n\nDecide next action."

    try:
        llm = _get_llm()
        raw = llm.invoke([
            {"role": "system", "content": PLANNER_SYS},
            {"role": "user", "content": user},
        ]).content
    except Exception as e:
        log.error("Planner LLM call failed: %s", e)
        out = dict(fallback)
        out["rationale"] = f"llm_error: {e}"
        return out

    result = _parse_json(raw)

    # _parse_json's failure-shape has "abstained"/"claims" keys, not "intent" —
    # use that to detect "the planner didn't return planner-shaped JSON".
    if "intent" not in result or result.get("intent") not in _VALID_INTENTS:
        out = dict(fallback)
        out["rationale"] = "json_parse_fallback"
        return out

    result.setdefault("standalone_query", None)
    result.setdefault("clarifying_question", None)
    result.setdefault("rationale", "")

    if result["intent"] == "retrieve" and not result["standalone_query"]:
        result["standalone_query"] = last_msg

    return result


# ── Conversational generator ─────────────────────────────────────────────────

GEN_SYS = """\
You are a fab shopfloor troubleshooting assistant. The operator is at a
tool, often under time pressure. Be concise, technical, and ground every
factual claim in the retrieved context using source_ids.

You may ask ONE follow-up question to narrow the diagnosis, only when it
would meaningfully change the next step.

If retrieved context is insufficient, set abstained=true.

Return STRICT JSON, no prose outside it:
{
  "abstained": bool,
  "abstain_reason": string or null,
  "claims": [ { "text": "...", "source_ids": ["c001", ...] } ],
  "follow_up_question": string or null,
  "suggested_action": string or null
}\
"""


def generate(convo: Conversation, chunks: List[Dict]) -> dict:
    """Generate a cited, conversational answer grounded in `chunks`.

    Never raises. Always returns a dict with keys: abstained,
    abstain_reason, claims, follow_up_question, suggested_action.
    Hallucinated source_ids are stripped (same as generator.py).
    """
    if not chunks:
        return {
            "abstained": True,
            "abstain_reason": "No context chunks provided.",
            "claims": [],
            "follow_up_question": None,
            "suggested_action": "Escalate to on-call engineer.",
        }

    ctx = "\n\n".join(f"[{c['id']}] {c['text']}" for c in chunks)
    user = (
        f"Conversation history:\n{convo.history_text(n=6)}\n\n"
        f"Retrieved context:\n{ctx}\n\n"
        f"Respond to the operator. Synthesize naturally; don't restate the question."
    )

    try:
        llm = _get_llm()
        raw = llm.invoke([
            {"role": "system", "content": GEN_SYS},
            {"role": "user", "content": user},
        ]).content
    except Exception as e:
        log.error("Generator LLM call failed: %s", e)
        return {
            "abstained": True,
            "abstain_reason": f"LLM call failed: {e}",
            "claims": [],
            "follow_up_question": None,
            "suggested_action": "Check vLLM server.",
        }

    result = _parse_json(raw)
    result.setdefault("abstained", False)
    result.setdefault("abstain_reason", None)
    result.setdefault("claims", [])
    result.setdefault("follow_up_question", None)
    result.setdefault("suggested_action", None)

    # Strip hallucinated source_ids (same validation as generator.py)
    valid_ids = {c["id"] for c in chunks}
    for claim in result["claims"]:
        claim["source_ids"] = [s for s in claim.get("source_ids", []) if s in valid_ids]
    result["claims"] = [c for c in result["claims"] if c.get("source_ids")]

    if not result["claims"] and not result["abstained"]:
        result["abstained"] = True
        result["abstain_reason"] = "All cited sources were invalid after validation."

    return result


# ── Reply rendering ────────────────────────────────────────────────────────

def _render_reply(verified: dict) -> str:
    """Turn a verified answer dict into operator-facing text with [n] markers."""
    if verified.get("abstained"):
        return (verified.get("abstain_reason") or
                "I don't have a reliable source for that. Recommend escalating.")

    cite_map: Dict[str, int] = {}
    counter = [1]

    def mark(sid: str) -> str:
        if sid not in cite_map:
            cite_map[sid] = counter[0]
            counter[0] += 1
        return f"[{cite_map[sid]}]"

    parts = []
    for c in verified.get("claims", []):
        markers = "".join(mark(sid) for sid in c.get("source_ids", []))
        parts.append(f"{c['text']} {markers}".strip())
    body = " ".join(parts)

    if verified.get("follow_up_question"):
        body += f"\n\nFollow-up: {verified['follow_up_question']}"
    if verified.get("suggested_action"):
        body += f"\n\nSuggested action: {verified['suggested_action']}"

    return body


# ── Turn handler ──────────────────────────────────────────────────────────

def handle_turn(convo: Conversation, message: str, retrieve_fn, verify_fn):
    """
    Process one operator message end-to-end.

    retrieve_fn(query, k) -> (chunks, status)
    verify_fn(answer_json, chunks_by_id) -> verified answer_json

    Returns: (reply_text, trace_dict)

    Never raises -- every stage is wrapped so a single bad turn degrades
    to a safe reply rather than crashing the conversation.
    """
    convo.add("operator", message)

    try:
        p = plan(convo)
    except Exception as e:
        log.error("plan() raised unexpectedly: %s", e)
        p = {"intent": "retrieve", "standalone_query": message,
             "clarifying_question": None, "rationale": f"plan_error: {e}"}

    intent = p.get("intent", "retrieve")
    if intent not in _VALID_INTENTS:
        intent = "retrieve"
        p["intent"] = "retrieve"

    # ── smalltalk ─────────────────────────────────────────────────────────
    if intent == "smalltalk":
        reply = "I'm here for troubleshooting. What equipment and what symptom?"
        convo.add("agent", reply, {"intent": intent, "plan": p})
        return reply, {"intent": intent, "plan": p}

    # ── clarify ───────────────────────────────────────────────────────────
    if intent == "clarify":
        q = p.get("clarifying_question") or "Which tool, and what symptom?"
        convo.add("agent", q, {"intent": intent, "plan": p})
        return q, {"intent": intent, "plan": p}

    # ── escalate ──────────────────────────────────────────────────────────
    if intent == "escalate":
        convo.escalated = True
        reply = "Escalating to the on-call engineer with full context. Stay safe."
        convo.add("agent", reply, {"intent": intent, "plan": p})
        return reply, {"intent": intent, "plan": p}

    # ── retrieve ──────────────────────────────────────────────────────────
    query = p.get("standalone_query") or message

    try:
        chunks, status = retrieve_fn(query, k=5)
    except Exception as e:
        log.error("retrieve_fn raised: %s", e)
        chunks, status = [], "error"

    if status != "ok" or not chunks:
        reply = ("I don't have a reliable source for that. "
                 "I recommend escalating to the on-call engineer.")
        convo.add("agent", reply, {"intent": intent, "plan": p, "abstained": True})
        return reply, {"intent": intent, "plan": p, "abstained": True,
                       "query": query, "chunks": []}

    try:
        raw = generate(convo, chunks)
    except Exception as e:
        log.error("generate() raised unexpectedly: %s", e)
        raw = {"abstained": True, "abstain_reason": f"Generator error: {e}",
               "claims": [], "follow_up_question": None,
               "suggested_action": "Check vLLM server."}

    chunks_by_id = {c["id"]: c for c in chunks}

    try:
        verified = verify_fn(raw, chunks_by_id)
    except Exception as e:
        log.error("verify_fn raised: %s", e)
        verified = dict(raw)
        verified.setdefault("stripped_count", 0)
        verified["critic_error"] = str(e)

    reply = _render_reply(verified)

    convo.add("agent", reply, {
        "intent": intent, "plan": p, "query": query,
        "chunks_used": list(chunks_by_id.keys()), "verified": verified,
    })
    return reply, {"intent": intent, "plan": p, "query": query,
                   "verified": verified, "chunks": chunks}
